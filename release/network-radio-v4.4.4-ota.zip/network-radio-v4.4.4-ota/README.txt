ESP32-S3 网络收音机 4.4.4 OTA 包

升级顺序：
1. 在管理后台“固件升级”中上传 network-radio-v4.4.4-firmware.bin。
2. 设备重启后，仅在需要更新台标或开机音乐时，通过“资源镜像升级”上传
   network-radio-v4.4.4-littlefs.bin。

注意：资源镜像会替换整个 LittleFS 分区。4.4.4 会自动补回内置电台，
但升级资源镜像前仍应备份自行添加或修改的电台。

